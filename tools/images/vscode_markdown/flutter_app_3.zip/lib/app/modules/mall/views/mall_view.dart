import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../controllers/mall_controller.dart';

class MallView extends GetView<MallController> {
  const MallView({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MallView'),
        centerTitle: true,
      ),
      body: const Center(
        child: Text(
          'MallView is working',
          style: TextStyle(fontSize: 20),
        ),
      ),
    );
  }
}
