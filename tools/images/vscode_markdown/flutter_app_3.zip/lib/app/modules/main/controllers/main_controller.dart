import 'package:flutter/material.dart';
import 'package:flutter_app_3/app/modules/home/views/home_view.dart';
import 'package:flutter_app_3/app/modules/mall/views/mall_view.dart';
import 'package:flutter_app_3/app/modules/user/views/user_view.dart';
import 'package:get/get.dart';

class MainController extends GetxController {
  List<Widget> bottomNavPages = []; // 底部导航栏各个可切换页面组
  var selectedIndex = 0.obs;

  @override
  void onInit() {
    super.onInit();
    bottomNavPages
      ..add(HomeView())
      ..add(MallView())
      ..add(UserView());
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void onItemTapped(int index) {
    selectedIndex.value = index;
  }
}
