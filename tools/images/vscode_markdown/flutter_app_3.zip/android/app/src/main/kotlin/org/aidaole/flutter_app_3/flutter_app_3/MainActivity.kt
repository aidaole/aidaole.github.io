package org.aidaole.flutter_app_3.flutter_app_3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
